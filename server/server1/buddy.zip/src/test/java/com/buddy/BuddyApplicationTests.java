package com.buddy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BuddyApplicationTests {

	@Test
	void contextLoads() {
	}

}
