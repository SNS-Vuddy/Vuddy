package com.buddy.exception;

public class InvalidateUserException extends RuntimeException{
    public InvalidateUserException() {
        super();
    }
}
