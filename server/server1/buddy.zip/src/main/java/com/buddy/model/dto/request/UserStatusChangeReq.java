package com.buddy.model.dto.request;

import lombok.Data;

@Data
public class UserStatusChangeReq {
    private String statusMessage;
}
