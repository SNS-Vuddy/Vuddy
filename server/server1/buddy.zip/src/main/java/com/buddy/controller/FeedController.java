package com.buddy.controller;

import com.buddy.model.dto.common.CommonRes;
import com.buddy.model.dto.request.FeedWriteReq;
import com.buddy.model.entity.Feed;
import com.buddy.model.entity.TaggedFriends;
import com.buddy.model.entity.User;
import com.buddy.model.service.FeedService;
import com.buddy.model.service.TaggedFriendsService;
import com.buddy.model.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequiredArgsConstructor
public class FeedController {

    private final FeedService feedService;
    private final UserService userService;
    private final TaggedFriendsService taggedFriendsService;

    @PostMapping("/api/v1/feed/write/{userId}")
    public CommonRes writeFeed(@PathVariable("userId") Long userId, @RequestBody FeedWriteReq req) {

        // 유저 정보 가져오기
        User user = userService.findByUserId(userId);

        // FeedWriteReq를 Feed 엔티티로 변환
        Feed feed = req.toFeedEntity(user);

        // 변환된 엔티티를 저장
        feedService.saveFeed(feed);

//         tags리스트에 담긴 닉네임들을 통해 유저를 찾아서 feed에 저장
        for (String nickname : req.getTags()) {
            User tagUser = userService.findByNickname(nickname);
            TaggedFriends taggedFriends = req.toTagEntity(feed, tagUser);
            taggedFriendsService.saveTaggedFriends(taggedFriends);
        }

        return new CommonRes(201, "피드 작성 성공");

    }

}
