package com.buddy.model.dto.request;

import lombok.Data;

@Data
public class LoginReq {

        private String nickname;

        private String password;
}
