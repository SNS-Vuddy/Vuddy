package com.buddy.model.entity.enums;

public enum UserFriendStatus {
    PENDING, ACCEPTED, DENIED
}
